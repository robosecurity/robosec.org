See http://code.google.com/p/brown-ros-pkg/wiki/gscam for documentation.
