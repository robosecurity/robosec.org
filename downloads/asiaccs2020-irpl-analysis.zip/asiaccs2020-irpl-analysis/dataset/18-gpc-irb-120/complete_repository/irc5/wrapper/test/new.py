MODULE MainModule
	VAR string str_item := "alex"
	PROC main()
	ENDPROC
ENDMODULE
