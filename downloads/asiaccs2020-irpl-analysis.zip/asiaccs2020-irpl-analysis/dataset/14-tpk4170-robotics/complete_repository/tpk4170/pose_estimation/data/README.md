# The Stanford Bunny

The PLY-file for the Stanford Bunny was downloaded from https://www.cc.gatech.edu/projects/large_models/bunny.html

The original dataset can be found here: http://graphics.stanford.edu/data/3Dscanrep/

