# abb_irb2400_support

## Overview

This package is part of the [ROS-Industrial][] program. See the main [abb][]
page on the ROS wiki for more information on usage.

## Supported Variants

- IRB 2400-12/1.55
- IRB 2400-20/1.55, use the IRB 2400-12/1.55 variant

## Deprecated

The unqualified IRB 2400 model will be removed in ROS-Lunar, please
use the IRB 2400-12/1.55 as a replacement.

[ROS-Industrial]: http://wiki.ros.org/Industrial
[abb]: http://wiki.ros.org/abb
