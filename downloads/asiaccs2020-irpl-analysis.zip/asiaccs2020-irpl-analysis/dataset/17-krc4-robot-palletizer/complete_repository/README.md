# KRC4-Robot-Palletizer
Industrial Kuka Robot Palletizer

KRC4 Language

@ingeniados - Raul Hernandez Garcia
