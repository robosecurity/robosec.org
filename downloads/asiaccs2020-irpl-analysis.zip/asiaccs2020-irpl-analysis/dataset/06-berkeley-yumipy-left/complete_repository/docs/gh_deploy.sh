#!/bin/sh
make gh-pages
cd ../docs
