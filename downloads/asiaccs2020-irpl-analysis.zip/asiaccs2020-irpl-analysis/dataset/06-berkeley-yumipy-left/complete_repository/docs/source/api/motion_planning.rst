Client-Side Motion Planning
===========================
By default, motion planning occurs on the YuMi controller.
However, to avoid obstacles the YuMi can plan motions using
the MoveIt! library on the client side.
This module is experimental.

YuMiMotionPlanner
~~~~~~~~~~~~~~~~~
.. autoclass:: yumipy.YuMiMotionPlanner
