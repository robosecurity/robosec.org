Exceptions
==========

YuMiCommException
~~~~~~~~~~~~~~~~~
.. autoclass:: yumipy.YuMiCommException

YuMiControlException
~~~~~~~~~~~~~~~~~~~~
.. autoclass:: yumipy.YuMiControlException
