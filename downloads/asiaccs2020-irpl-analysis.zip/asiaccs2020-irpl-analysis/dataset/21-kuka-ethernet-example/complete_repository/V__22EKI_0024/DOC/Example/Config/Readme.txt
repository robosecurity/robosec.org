Target directory:
C:\KRC\ROBOTER\Config\User\Common\EthernetKRL