%% Parameters

kuka=RobotConnectorKUKA;

offsetX=411.69;
offsetY=-285.27;
offsetZ=342.19;
offsetA=0;
offsetB=0;
offsetC=180;

